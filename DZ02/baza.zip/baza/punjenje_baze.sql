Punjenje baze:

INSERT INTO Clan (ime, prezime, email, telefon) VALUES
('Ana', 'Anić', 'ana.anic@gmail.com', '0911111111'),
('Marko', 'Marić', 'marko.maric@gmail.com', '0922222222'),
('Ivana', 'Ivić', 'ivana.ivic@gmail.com', '0933333333'),
('Luka', 'Lukić', 'luka.lukic@gmail.com', '0944444444'),
('Petra', 'Perić', 'petra.peric@gmail.com', '0955555555');

INSERT INTO Trener (ime, prezime, specijalizacija) VALUES
('Ivan', 'Horvat', 'Funkcionalni trening'),
('Mia', 'Kovač', 'Yoga'),
('Filip', 'Novak', 'Individualni trening');

INSERT INTO Trening (naziv, tip, kapacitet) VALUES
('Jutarnji cardio', 'grupni', 15),
('Yoga za početnike', 'grupni', 12),
('Personalni trening', 'individualni', 1),
('Kružni trening', 'grupni', 10);

INSERT INTO Dvorana (naziv, kapacitet) VALUES
('Dvorana A', 20),
('Dvorana B', 15),
('Mala dvorana', 5);

INSERT INTO Paket (naziv, broj_treninga, cijena) VALUES
('Mjesečni paket', 12, 45.00),
('Neograničeni paket', 999, 70.00),
('Individualni paket', 8, 90.00);

INSERT INTO Termin (datum, vrijeme, trajanje, trening_id, dvorana_id) VALUES
('2026-04-10', '08:00:00', 60, 1, 1),
('2026-04-10', '18:00:00', 60, 2, 2),
('2026-04-11', '10:00:00', 45, 3, 3),
('2026-04-11', '19:00:00', 60, 4, 1),
('2026-04-12', '17:00:00', 60, 1, 2);

INSERT INTO Clanarina (clan_id, paket_id, datum_pocetka, datum_zavrsetka, status) VALUES
(1, 1, '2026-04-01', '2026-04-30', 'aktivna'),
(2, 2, '2026-04-01', '2026-04-30', 'aktivna'),
(3, 1, '2026-04-05', '2026-05-04', 'aktivna'),
(4, 3, '2026-04-01', '2026-04-30', 'aktivna'),
(5, 1, '2026-03-01', '2026-03-31', 'istekla');

INSERT INTO Uplata (clanarina_id, iznos, datum) VALUES
(1, 45.00, '2026-04-01'),
(2, 70.00, '2026-04-01'),
(3, 45.00, '2026-04-05'),
(4, 90.00, '2026-04-01'),
(5, 45.00, '2026-03-01');

INSERT INTO Rezervacija (clan_id, termin_id, status) VALUES
(1, 1, 'potvrdena'),
(2, 2, 'potvrdena'),
(3, 1, 'potvrdena'),
(4, 3, 'potvrdena'),
(1, 4, 'na cekanju');

INSERT INTO Raspored (trener_id, termin_id) VALUES
(1, 1),
(2, 2),
(3, 3),
(1, 4),
(2, 5);
